#ifndef CONTACT_H
#define CONTACT_H

#define CONTACT_SUCCESS 0
#define CONTACT_FAILURE 1
 
struct Contact{
	int contact_id;
	char contact_name[50];
	char phone[50];
};

extern struct PDS_RepoInfo *repoHandle;

// Add the given contact into the repository by calling put_rec_by_key
int add_contact( struct Contact *c );

// Overwite existing contact with the given contact pds_overwrite
// Hint: call the PDS function as follows
// pds_overwrite(c->contact_id, c);
int overwrite_contact( struct Contact *c );

// Display contact info in a single line as a CSV without any spaces
void print_contact( struct Contact *c );

// Use get_rec_by_key function to retrieve contact
int search_contact( int contact_id, struct Contact *c );

// Load all the contacts from a CSV file
int store_contacts( char *contact_data_file );

// Use get_rec_by_non_ndx_key function to retrieve contact
int search_contact_by_phone( char *phone, struct Contact *c, int *io_count );

/* Return 0 if phone of the contact matches with phone parameter */
/* Return 1 if phone of the contact does NOT match */
/* Return > 1 in case of any other error */
int match_contact_phone( void *rec, void *key );

// Function to delete contact by ID
int delete_contact ( int contact_id );

#endif
